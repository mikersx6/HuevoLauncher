
-- The render cache was discovered to not speed up LOD loading,
-- so to reduce DB file size it was removed.
drop table DhRenderData;
